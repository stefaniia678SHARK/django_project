//alert ('Welcome to my website!')

var message_timeout = document.getElementById("message_timer");


setTimeout(function()
{
    message_timeout.style.display = "none";

}, 5000);