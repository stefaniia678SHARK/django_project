The user logs into the app, where they see a dashboard with a summary of events and work orders. They can update their view - to make thier dahsboard light mode or dark mode, they also can make changes in thier profile.
Super user aka admin is putting work_orders for a particular user.
User will be only available to update and delete events, and also put work_orders.

When you open the project first you need to register after this the page will bring you to log in page, and after you log in you will see your dashboard.
Running a project is available by GitHub, the only assumption being that Python 3 is installed on the system.
